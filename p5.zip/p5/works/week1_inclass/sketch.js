function setup(){
createCanvas(800,600);
    
    
    
}
function draw(){
background(255,204,0);
fill(50, 101, 214);
noStroke();
rect(350, 200, 60, 60, 30, 30, 5, 5);
noFill();
    //fill(244, 233, 186);   
fill(244, 233, 186);

ellipse(370, 150, 100, 100);    

noFill();
stroke(0);
curve(10, 30, 300, 180, 50, 184, 373, 361);
line(20, 160, 45, 15,);
    
}